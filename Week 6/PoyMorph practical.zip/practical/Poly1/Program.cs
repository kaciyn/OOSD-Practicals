﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Poly1
{
    class Program
    {
        static void Main(string[] args)
        {
          /*
           * Add your code here
           * 
           */ 
            Console.ReadLine();
        }
    }
}
